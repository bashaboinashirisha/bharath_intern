# Weather-1
WEB DEVELOPMENT INTERNSHIP (Unpaid Internship) 

Weather Website :
Build a website using Html, Css, Js that
fetches weather data from an API and
displays the current weather conditions.
Click Here to 

href="https://abs6187.github.io/Weather-1/"
